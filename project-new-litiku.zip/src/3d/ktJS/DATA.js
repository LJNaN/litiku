export const DATA = {};
