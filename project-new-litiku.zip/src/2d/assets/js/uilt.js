const getImageUrl = (name) => {
  return `/img/${name}.png`
}
export { getImageUrl }