<template>
  <div class="main">
    <div class="circular"></div>
    <div class="circular"></div>
    <div class="circular"></div>
    <div class="circular"></div>
    <div class="circular"></div>
    <div class="circular"></div>
  </div>
</template>

<script setup>
</script>

<style lang="less" scoped>
.main {
  .circular {
    height: 0.828vh;
    width: 0.21vw;
    transform: rotate(40deg);
    background-color: #a4793b;
  }
}
</style>
