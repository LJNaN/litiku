const wsAPI = 'ws://192.168.8.170:5443/null'

window.wsAPI = wsAPI